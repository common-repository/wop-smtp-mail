<?php

namespace WOPMailSMTP;

/**
 * Awesome Motive Notifications
 *
 * This creates a custom post type (if it doesn't exist) and calls the API to
 * retrieve notifications for this product.
 *
 * @package    AwesomeMotive
 * @author     Benjamin Rojas
 * @license    GPL-2.0+
 * @copyright  Copyright (c) 2017, Retyp LLC
 * @version    1.0.2
 */
class AM_Notification{
	/**
	 * The api url we are calling.
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	public $api_url = '#';

	/**
	 * A unique slug for this plugin.
	 * (Not the WordPress plugin slug)
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	public $plugin;

	/**
	 * The current plugin version.
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	public $plugin_version;

	/**
	 * Flag if a notice has been registered.
	 *
	 * @since 1.0.0
	 *
	 * @var bool
	 */
	public static $registered = false;

	/**
	 * Construct.
	 *
	 * @since 1.0.0
	 *
	 * @param string $plugin The plugin slug.
	 * @param mixed $version The version of the plugin.
	 */







	/**
	 * Grab the current plan level.
	 *
	 * @since 1.0.0
	 *
	 * @return string The current plan level.
	 */


	/**
	 * Dismiss the notification via AJAX.
	 *
	 * @since 1.0.0
	 */
	public function dismiss_notification() {
		if ( ! current_user_can( apply_filters( 'am_notifications_display', 'manage_options' ) ) ) {
			die;
		}

		$notification_id = intval( $_POST['notification_id'] );
		update_post_meta( $notification_id, 'viewed', 1 );
		die;
	}

	/**
	 * Revokes notifications.
	 *
	 * @since 1.0.0
	 *
	 * @param array $ids An array of notification IDs to revoke.
	 */
	public function revoke_notifications( $ids ) {
		// Loop through each of the IDs and find the post that has it as meta.
		foreach ( (array) $ids as $id ) {
			$notifications = $this->get_plugin_notifications( -1, array( 'post_status' => 'all', 'meta_key' => 'notification_id', 'meta_value' => $id ) );
			if ( $notifications ) {
				foreach ( $notifications as $notification ) {
					update_post_meta( $notification->ID, 'viewed', 1 );
				}
			}
		}
	}
}
